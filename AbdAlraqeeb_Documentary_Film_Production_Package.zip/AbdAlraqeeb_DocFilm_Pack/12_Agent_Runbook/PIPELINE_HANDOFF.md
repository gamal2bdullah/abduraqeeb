# Pipeline Handoff Standard

## Stage 00 – Research Lock
Input: SOURCE_REGISTRY_AR.md + FACTCHECK_LOG_AR.md.
Output: research_locked.json.
Pass: no unresolved hard claims in final script without uncertainty tags.

## Stage 01 – Character Lock
Input: verified images.
Output: character_reference_pack + identity embeddings/seed data inside production system only.
Pass: stable face across 10 test generations.

## Stage 02 – Visual Previz
Input: FINAL_7MIN_SCRIPT_AR.md + SHOTLIST_AR.csv.
Output: storyboard frames + animatic.
Pass: narration timing within ±0.25 sec per scene.

## Stage 03 – Voice Lock
Output: narrator + reenactment voice profiles.
Pass: same voice identity across all generated takes; no archival impersonation claim.

## Stage 04 – Generation
Generate in native 4K where supported. Otherwise generate high-resolution source then use high-quality restoration/upscale, never low-quality interpolation.

## Stage 05 – Editorial
Replace any generated visual that unintentionally states an uncertain fact as certain.

## Stage 06 – Sound
Dialogue must remain intelligible over SFX/music. Use silence around major historical claims.

## Stage 07 – Color/Finishing
Unify generated and archival elements without making archival footage look synthetic.

## Stage 08 – QC
Run technical + historical + identity + dialect tests.

## Stage 09 – Final Render
Produce 4K and 1080; verify every output by decoding the complete file, checking duration, frame count, audio channels, codec, bitrate, and subtitle sync.
