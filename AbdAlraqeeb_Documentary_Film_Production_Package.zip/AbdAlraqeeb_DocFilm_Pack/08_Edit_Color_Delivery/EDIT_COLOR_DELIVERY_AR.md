# Edit / Color / Delivery Specification

## Timeline
- 3840×2160 UHD
- 24 fps CFR
- Rec.709 SDR
- 7:00 hard ceiling

## Edit
- average shot duration 3–8s
- longer documentary holds 6–12s for evidence/letters
- no transitions except hard cuts, short dissolves, map wipes
- titles: restrained documentary typography

## Color
- archival scans: restore dust/scratches without fake detail; preserve grain.
- generated reconstruction: natural contrast, no plastic skin.
- Aden slightly warmer/humid.
- Sana'a cooler highland daylight.
- Night scenes tungsten motivated.

## Export 4K
H.264 High Profile, 8-bit 4:2:0 for compatibility.
Target VBR 60–100 Mbps, max 120 Mbps.
Keyframe 2s.
AAC-LC 320 kbps, 48kHz stereo.

## Export 1080
H.264 High Profile, 15–30 Mbps.
Keyframe 2s.
AAC-LC 320 kbps.

## Subtitles
Arabic SRT, burned-in optional, external SRT mandatory.
No line > 42 visible Arabic characters where possible.
Time subtitles to breath, not word-by-word.
