# Asset Manifest — Required Outputs

## Character reference pack
- abdulraqeeb_Aden_1956_front.png
- abdulraqeeb_Aden_1956_3qL.png
- abdulraqeeb_Aden_1956_3qR.png
- abdulraqeeb_Aden_1956_profileL.png
- abdulraqeeb_Aden_1956_profileR.png
- abdulraqeeb_1962_front.png
- abdulraqeeb_1964_cairo_front.png
- abdulraqeeb_siege_1967_front.png
- abdulraqeeb_siege_1967_3qL.png
- abdulraqeeb_siege_1967_3qR.png
- abdulraqeeb_siege_1967_fullbody.png
- abdulraqeeb_1969_neutral.png

## Environment references
- Aden_printshop_1956
- Aden_school_1950s
- Aden_street_1962
- Sanaa_1967_old_city
- Aiban_1968
- Shaub_1967
- Bani_Hashish_1967
- Hodeidah_1968
- road_Hodeidah_Sanaa_1968
- Cairo_military_training_1964

## Documentary graphics
- map_Aden_Sanaa_1962.svg
- map_Sanaa_siege_axes.svg
- map_Hodeidah_Sanaa_relief_1968.svg
- timeline_1962_1969.svg
- 40_operations_visual.svg

## Audio
- VO_narrator.wav
- VO_abdulraqeeb_reenactment.wav (only source-backed lines)
- VO_tais_testimony_reenactment.wav
- VO_kahlani_testimony_reenactment.wav
- VO_noman_letter.wav
- music_theme_A.wav
- music_theme_B.wav
- music_theme_C.wav
- music_theme_D.wav
- radio_static.wav
- printshop_foley.wav
- siege_ambience.wav

## Archive evidence
Use source-specific folders with:
- original file
- source URL
- screenshot or archive capture if permitted
- date
- rights status
- verification note
