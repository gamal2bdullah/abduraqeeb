# Reference Image Sources

Use these pages to locate historical portraits/reference imagery. Do not assume that any image is licensed for commercial reuse; verify rights before embedding in the final film.

1. عبدالرقيب عبدالوهاب — صحيفة النداء portrait/profile:
https://www.alndaa.net/104140/abdulraqib-abdulwahab-hero-seventies-first-chief-staff-elected

2. حسن العمري — archival photo album:
https://alamree.net/album-hason-alamri_01.htm

3. عبداللطيف ضيف الله — Egyptian Presidency archival profile:
https://www.presidency.eg/AR/%D8%A7%D9%84%D8%B1%D8%A6%D8%A7%D8%B3%D8%A9/%D9%82%D8%A7%D8%A6%D9%85%D8%A9-%D8%A7%D9%84%D8%B4%D8%B1%D9%81/%D8%B9%D8%A8%D8%AF-%D8%A7%D9%84%D9%84%D8%B7%D9%8A%D9%81-%D8%B6%D9%8A%D9%81-%D8%A7%D9%84%D9%84%D9%87/

4. قاسم منصر — historical profile with portrait:
https://www.marefa.org/%D9%82%D8%A7%D8%B3%D9%85_%D9%85%D9%86%D8%B5%D8%B1

5. أحمد محمد نعمان — historical material/portrait:
https://www.alndaa.net/102517/ahmed-mohammed-noman-between-interviews-memoirs-biography-political

6. أحمد عبدربه العواضي — biographical reference:
https://www.almashhad.news/news/292901

These are reference acquisition targets, not proof of copyright clearance or exact shot context.
