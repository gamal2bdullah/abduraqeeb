# Final QC Checklist

## الصورة
- [ ] 3840×2160 file exists.
- [ ] 24fps CFR.
- [ ] No accidental modern objects.
- [ ] Face identity stable in every multi-shot sequence.
- [ ] Clothing era consistent.
- [ ] Weapons era consistent.
- [ ] No AI hallucinated archival labels.
- [ ] All map labels historically/geographically checked.

## الصوت
- [ ] Dialogue fully intelligible on phone speakers.
- [ ] No synthetic voice presented as archival.
- [ ] Distinct character voice identities stable.
- [ ] Dialect is natural, not comedic.
- [ ] No clipping.
- [ ] True peak <= -1 dBTP.
- [ ] Stems rendered.

## التاريخ
- [ ] Every direct factual statement has source ID.
- [ ] Every oral testimony labeled.
- [ ] Every contested detail marked as contested.
- [ ] «40 عملية» used, not «40 معركة».
- [ ] Appointment date phrased with source uncertainty.
- [ ] Death details not overclaimed.

## التحرير
- [ ] Total duration <= 07:00.
- [ ] First 18 seconds contain hook + identity.
- [ ] No scene repeats prior information unless it changes interpretation.
- [ ] Ending returns to the printing-type motif.
- [ ] Arabic subtitles synchronized.

## Deliverables
- [ ] final_4k.mp4
- [ ] final_1080.mp4
- [ ] transcript_ar.txt
- [ ] subtitles_ar.srt
- [ ] master_audio_mix.wav
- [ ] stems
- [ ] source_log.csv
- [ ] factcheck_log.csv
- [ ] visual asset manifest
- [ ] editable project archive
