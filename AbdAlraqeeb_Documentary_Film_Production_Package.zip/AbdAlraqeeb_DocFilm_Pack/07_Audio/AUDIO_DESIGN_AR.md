# Audio Design & Mix

## طبقات الصوت
1. Dialogue/Narration
2. Historical ambience
3. Foley
4. Weapons/impact restrained
5. Radio static
6. Music score
7. Archival source audio (إن توفر)

## الهوية الصوتية
- لا موسيقى «ملاحم» طوال الفيلم.
- استخدم الصمت كأداة درامية بعد الجمل الثقيلة.
- أصوات المطبعة في البداية تعود في النهاية كـmotif.
- صوت اللاسلكي يظهر كعلامة انتقال إلى مرحلة القيادة.
- صوت القذيفة لا يعلو على النص في الفيلم الوثائقي.

## Foley
- metal type clicks
- paper feed
- hand on map
- boots on stone/dust
- cloth friction
- distant artillery
- radio static
- vehicle engine compatible with era
- wind on highland stone

## Music
Theme A: «Ink to Radio» — minimal strings/low strings + subtle frame drum texture.
Theme B: «Siege» — low drone, sparse percussion.
Theme C: «Road Opens» — restrained harmonic lift.
Theme D: «After Victory» — almost no music, piano/oud harmonic texture optional.

## Mix target
- Dialogue intelligibility first.
- Web final: -14 to -16 LUFS integrated حسب المنصة مع true peak <= -1 dBTP.
- Preserve dynamic range in battle segments.
- WAV master 48kHz/24-bit.
