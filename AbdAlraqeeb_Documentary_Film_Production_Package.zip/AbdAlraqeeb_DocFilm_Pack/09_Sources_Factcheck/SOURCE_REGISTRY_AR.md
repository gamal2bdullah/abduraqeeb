# Source Registry / Fact-Check Backbone

## S1 — Oxford Academic
Asher Orkaby, *Beyond the Arab Cold War: The International History of the Yemen Civil War, 1962–68*, chapter «The Siege of Sana’a and the End of the Yemen Civil War», Oxford University Press, 2017.
https://doi.org/10.1093/acprof:oso/9780190618445.003.0011
Use for: Egyptian withdrawal in Nov 1967; 70-day siege; central historical context; February 1968 lifting.
Confidence: HIGH.

## S2 — صحيفة الثورة / شهادة حسين «التيس»
«الشهيد عبدالرقيب عبدالوهاب هو بطل حرب السبعين بدون منازع»، 2012، مقابلة صلاح سيف مع حسين عبدالله بن عبدالله الملقب «بالتيس».
https://althawrah.ye/archives/24121
Use for: transfer to paratroops, mission of paratroops/commandos, جرش/بني حشيش/قرية الدجاج, food/water/cold testimony, participation with عبدالرقيب, تبة جهراس, clothing/rank anecdote.
Confidence: MEDIUM-HIGH for testimony; lower for independently unverified event details.

## S3 — أخبار اليوم
«عبدالرقيب … أيقونة السبعين المجيد»، 2025.
https://akhbaralyom.net/news_details.php?sid=181769
Use for: biography summary, military role, 40 operations quote, command structure during siege, date range as presented by the article.
Confidence: MEDIUM; use with corroboration.

## S4 — خيوط
«28 نوفمبر/تشرين الثاني 1967».
https://www.khuyut.net/blog/al-sabeen-siege
Use for: siege opening context, aviation/civil transport, Feb 8 road opening, regional context.
Confidence: MEDIUM-HIGH where it cites primary/archival books.

## S5 — LSE thesis
*Yemen’s Revolutionary Moment, Collective Memory and Contentious Politics*.
https://etheses.lse.ac.uk/3213/1/Thiel_citizens_revolt_for_a_modern_state.pdf
Use for: siege as survival crisis, elite flight, 70-day dates, force balance context.
Confidence: HIGH scholarly synthesis; verify direct quotes against primary works.

## S6 — University page on book «عبدالرقيب عبدالوهاب.. سؤال الجمهورية»
https://qau.edu.ye/journal/20154
Use for: existence/metadata of the 2025 book and its stated methodology (memoirs + oral testimonies).
Confidence: HIGH for publication metadata, not a substitute for reading the book itself.

## S7 — حوار/مواد عن عبدالرقيب ومقتله
Use only for triangulation of late-life narratives; never treat one later journalistic account as sole proof of contested details.

## Known uncertainty flags
U1: birth year appears as 1941 vs 1943 in sources.
U2: exact appointment date as Chief of Staff varies across later accounts.
U3: exact date of death varies in some sources, while 25 Jan 1969 is used by the 2025 book announcement.
U4: exact sequence of the final house encounter and corpse-treatment has conflicting accounts.
U5: exact print-shop name and exact print materials have not been firmly established from the open sources reviewed.
U6: precise dialect/voice of historical figures is not directly recoverable unless archival recordings exist.
